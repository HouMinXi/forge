"""Check archived packet expectations or replay the fixed #552 sample offline."""
import argparse
import hashlib
import os
from pathlib import Path
import re
import subprocess as sp
import sys
import uuid

BASE = Path(__file__).resolve().parent
SUBJECT = "3fae8be7a6080ad645d09ec3e142081a678e9c8b"
TOOLS = "f014d8e2bea041c62c3a239e2ce4cd5179611376"
SOURCE = "src/code_forge/machine.py"
TEST = "tests/test_contract_flag.py"
NODE = TEST + "::test_working_contract_clean_credit[changed]"
OBSERVER = "a9aac0ef16e69410391b56f849eeb3afd846604ea8f1411e06d0cc3af30853eb"
CONTROL = "11eb039a84091bb29cc35bd5aa67fbad9feb10215dbf7f49474489f6d86bafa9"


def need(ok, why):
    if not ok:
        raise SystemExit(why)


def git(root, *args):
    return sp.check_output(["git", "--no-lazy-fetch", "-C", str(root), *args], text=True).strip()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("subject", type=Path)
    p.add_argument("tools", type=Path)
    p.add_argument("--replay", type=Path, help="fresh output directory outside both checkouts")
    args = p.parse_args()
    subject, tools = args.subject.resolve(), args.tools.resolve()
    tool_dir = tools / "docs/eval/r3-evidence-packet"
    for root, sha in [(subject, SUBJECT), (tools, TOOLS)]:
        need(git(root, "rev-parse", "HEAD") == sha, "wrong checkout revision")
        need(not git(root, "status", "--porcelain"), "checkout is not clean")
    expected = {name: sha for sha, name in (
        line.split() for line in (BASE / "tracked-inputs.sha256").read_text().splitlines()
    )}
    for path in (SOURCE, TEST):
        need(digest(subject / path) == expected[path], f"input digest differs: {path}")
    need(digest(tool_dir.parent / "r3-target-line/target_hits.py") == OBSERVER, "observer digest differs")
    need(digest(BASE / "forge_oracle_control.py") == CONTROL, "control helper digest differs")
    out = args.replay.resolve() if args.replay else BASE / "recorded"
    if args.replay:
        import pytest
        need(pytest.__version__ == "9.2.0" and sys.version_info[:2] == (3, 12), "use Python 3.12 and pytest 9.2.0")
        need(not any(out.is_relative_to(root) for root in (subject, tools)), "output must be outside both checkouts")
        out.mkdir(exist_ok=False)
    seen = set()
    for stage, exit_code, call in (("baseline", 0, "passed"), ("controlled", 1, "failed"), ("restored", 0, "passed")):
        packet = out / f"{stage}.packet.json"
        if args.replay:
            env = {k: v for k, v in os.environ.items() if not k.startswith(("PYTEST_", "FORGE_ORACLE_"))}
            env.update(PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1", PYTHONPATH=os.pathsep.join(map(str, (subject / "src", BASE))))
            if stage == "controlled":
                env["FORGE_ORACLE_CONTROL"] = "synthetic-readback"
            completed = sp.run([
                sys.executable, str(tool_dir / "packet.py"), "--root", str(subject), "--source", SOURCE,
                "--node", NODE, "--file", SOURCE, "--line", "1880", "--run-id", uuid.uuid4().hex,
                "--output", str(packet), "--", "-q", "--confcutdir", str(subject), "-p", "forge_oracle_control", NODE,
            ], env=env, cwd=subject, capture_output=True, text=True)
            log = completed.stdout
            (out / f"{stage}.stdout").write_text(log)
            (out / f"{stage}.stderr").write_text(completed.stderr)
            (out / f"{stage}.exit").write_text(f"{completed.returncode}\n")
        else:
            log = (out / f"{stage}.excerpt.txt").read_text()
        need(int((out / f"{stage}.exit").read_text()) == exit_code, f"{stage}: unexpected process exit")
        if exit_code:
            need("test_contract_flag.py:187: AssertionError" in log and
                 "real_readback=0 supplied_readback=2" in log and "At index 2 diff: 2 != 0" in log,
                 "controlled stage did not fail at the original assertion for the expected reason")
        markers = re.findall(r"^forge-r3-packet run_id=([0-9a-f]{32}) sha256=([0-9a-f]{64})$", log, re.M)
        need(len(markers) == 1, f"{stage}: missing or duplicate stdout identity")
        run_id, packet_digest = markers[0]
        need(run_id not in seen, "duplicate execution identity")
        seen.add(run_id)
        sp.run([
            sys.executable, str(tool_dir / "verify.py"), str(packet), "--expect-run-id", run_id,
            "--expect-commit", SUBJECT, "--expect-source-sha256", expected[SOURCE],
            "--expect-test-sha256", expected[TEST], "--expect-observer-sha256", OBSERVER,
            "--expect-target-file", SOURCE, "--expect-line", "1880", "--expect-node", NODE,
            "--expect-call", call, "--expect-exit", str(exit_code), "--expect-hits", "1",
            "--expect-packet-sha256", packet_digest,
        ], check=True)
        print(f"{stage}: {call}, exit={exit_code}, hits=1", flush=True)
    for path in (SOURCE, TEST):
        need(digest(subject / path) == expected[path], f"input changed: {path}")
    need(not git(subject, "status", "--porcelain"), "subject checkout changed")


if __name__ == "__main__":
    main()
