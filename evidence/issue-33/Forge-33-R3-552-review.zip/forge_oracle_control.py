"""Test-only negative control: substitute one readback, never write product state."""

from copy import copy
from hashlib import sha256
import os
from pathlib import Path

import pytest

NODE = "tests/test_contract_flag.py::test_working_contract_clean_credit[changed]"


@pytest.hookimpl(wrapper=True)
def pytest_runtest_call(item):
    if item.nodeid != NODE or os.environ.get("FORGE_ORACLE_CONTROL") != "synthetic-readback":
        return (yield)
    module = item.module
    original = module.load_state
    reads = 0

    def load_for_assertion(path):
        nonlocal reads
        reads += 1
        actual = original(path)
        if reads != 2:
            return actual
        raw = Path(path).read_bytes()
        assert actual.verdict.value == "FAIL"
        assert actual.consecutive_clean_rounds == 0
        substitute = copy(actual)
        substitute.consecutive_clean_rounds = 2
        assert Path(path).read_bytes() == raw
        print(f"oracle-control: real_readback=0 supplied_readback=2 state_sha256={sha256(raw).hexdigest()}")
        return substitute

    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(module, "load_state", load_for_assertion)
        return (yield)
