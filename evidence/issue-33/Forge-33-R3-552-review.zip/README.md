# Forge #33 · #552 R3 独立复核包

**这份包验证原断言能识别错误的读回值，不宣称在产品里制造或复现了回归。**

被测的是 [#552 的实际合并版本](https://github.com/HouMinXi/forge/commit/3fae8be7a6080ad645d09ec3e142081a678e9c8b)。
固定测试为 `tests/test_contract_flag.py::test_working_contract_clean_credit[changed]`，追踪
`src/code_forge/machine.py:1880`（清零旧轮次）。原断言在
[测试第 187 行](https://github.com/HouMinXi/forge/blob/3fae8be7a6080ad645d09ec3e142081a678e9c8b/tests/test_contract_flag.py#L185-L189)。

| 阶段 | 已落盘值 / 交给测试的值 | 原测试 call | pytest 退出码 | 改动行命中 |
|---|---|---|---|---|
| 基线 | 0 / 0 | 通过 | 0 | 1 |
| 合成读回 | 0 / 2 | 在原断言处失败 | 1 | 1 |
| 恢复 | 0 / 0 | 通过 | 0 | 1 |

控制阶段先读取真实落盘状态，再只替换测试模块第二次读取时收到的副本；helper 确认文件字节未变。
没有改状态机、原测试、门禁或 Forge 的真实结果。三次测试使用同一被测提交和源码/测试摘要，各有不同运行 ID。
fixture 从现有测试走本地合成后端；不需要 Forge 服务、模型、令牌或联网请求。

## 一次复核

使用两个干净且互不包含的检出目录：

- `SUBJECT`：[被测版本 3fae8be7](https://github.com/HouMinXi/forge/tree/3fae8be7a6080ad645d09ec3e142081a678e9c8b)。
- `TOOLS`：[核验与复跑工具 f014d8e2](https://github.com/HouMinXi/forge/tree/f014d8e2bea041c62c3a239e2ce4cd5179611376)，即 #596 合并版本。

用支持 `--no-lazy-fetch` 的 Git、Python 3.12、pytest 9.2.0、PyYAML 6.0.3、unidiff 0.7.5。
实测 Python 3.12.14；使用 pytest 不自动发现外部插件的方式。不同安装缺少 pytest-asyncio 时，
pytest 可能提示未知配置项，固定测试本身不依赖它。依赖与检出准备好后可以断网执行。

从解压目录运行：

```sh
sha256sum -c SHA256SUMS
python check.py "$SUBJECT" "$TOOLS"
python check.py "$SUBJECT" "$TOOLS" --replay /absolute/path/to/new-run-directory
```

第二条核验本包中的三份历史回执；第三条会另存三份新回执和完整复跑日志，目录必须尚不存在且不在两个检出内。
应看到 `passed / failed / passed`，退出码 `0 / 1 / 0`，各命中 1 次，运行 ID 应和归档不同。
控制阶段还必须看到 `test_contract_flag.py:187: AssertionError` 和 `2 != 0`。
`recorded/*.excerpt.txt` 是从历史 stdout 提取并清去本地绝对路径的片段，不是完整日志。归档内的摘要
可检查一致性，不能由此证明归档发布者身份；独立复核宜跑第三条而不是只查看摘要。

## 放回 #33

- [配置侧对照](https://github.com/HouMinXi/forge/issues/33#issuecomment-7208216767)：只证明匹配测试文件存在就能改变现有检查的提示或退出码，并不证明跑了测试。
- [#596 的同版对照](https://github.com/HouMinXi/forge/pull/596)：真实改动行命中 1，同一文件里只改合同文件名的用例也绿、却命中 0，不能认领此次覆盖。参见该版本的 `docs/eval/r3-evidence-packet/replay_552.sh`。
- 本包：加上原断言能区分正确和错误读回值的单条证据。不替代测试对真实产品回归的验证；不扩大到别的语句、用例或组件。
- 请求独立审阅者复跑，并只签收这条证据。#33 保持开放，R3 不勾；不改现有检查、退出码或回执规则。
