# Forge #33: independent R3 fixed-sample rerun

This is a new replay, not recovery of the historical packets. Tool checkout:
`60b8feb0fc8fc79d7a6bb4cf679384e8d139b416` (merged #575). Sample checkout:
`5a41cf44339a09fd233dea91af9d88993f88d308`. CPython 3.12.14, pytest 9.2.0,
third-party pytest plugin autoload disabled.

[Two-checkout procedure](https://github.com/HouMinXi/forge/blob/60b8feb0fc8fc79d7a6bb4cf679384e8d139b416/docs/eval/r3-evidence-packet/RESULTS.md).
Target: `src/code_forge/llm_invoke.py:2506`.
Node: `tests/test_excerpt_json_encoding.py::test_correct_json_encoding_preserves_literal_source`.
Only the synthetic payload value changed in the controlled stage. The original
assertion failed at line 46. The test file was restored byte-for-byte, and all
five input hashes rechecked. All three packets were accepted by the verifier
against their own expected run, revision, hashes, target, call result and exit.

| Stage | pytest exit | Target call | hits | Run ID | Packet payload digest |
| --- | ---: | --- | ---: | --- | --- |
| baseline | 0 | passed | 2 | `3c7a619984cd1019816fe62203acb878` | `b54754767deb41b384fe27a5a192c6e9b00b087427998a236240cd0f3ae409be` |
| controlled | 1 | failed | 2 | `d31917c6563b2e2930dae450980b9529` | `55e36799bd6d17dd6b818ec8693736222ac91c320d005871cf703517d5537ef1` |
| restore | 0 | passed | 2 | `27076c67bf067a62bda5128e7a1f640d` | `4f042da00d25c6e827ab694f090d8e2e0496b8786026350c4dd8fc4cecebe565` |

The JSON packets are byte-for-byte outputs. Temporary checkout and Python environment paths
in textual logs were replaced with placeholders. The manifest records SHA-256
of the delivered files; its file digest differs by design from the canonical
payload digest stored inside each packet.

## Acceptance boundary

Accept as evidence for the single trusted-runner offline sample: named source
and exact pytest node, same-execution hits and call phase, and discrimination
by the original assertion for the controlled value. Existing negative controls
in #575 and the separate file-call execution reader in #576 stay separate; this
rerun does not claim to have repeated each of them. Neither an authenticity
attestation nor production R3/CI integration, full path coverage, or complete
#33 acceptance. The standard R3 check still detects artifact presence.
